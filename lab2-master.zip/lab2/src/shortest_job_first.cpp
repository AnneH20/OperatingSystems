#include "shortest_job_first.hpp"

#include<algorithm>

namespace cse4733 {


// Comparator function for SJF scheduling
bool shortest_job_first::compare(const std::shared_ptr<cse4733::Process>& a,
                                    const std::shared_ptr<cse4733::Process>& b) {
    return a->get_burst_time() < b->get_burst_time();
}

void shortest_job_first::run(std::vector<std::shared_ptr<cse4733::Process>>& processes)
{
    int current_time = 0;
    int total_waiting = 0;
    int total_turnaround = 0;

    // TODO:
    // Step 1: Sort processes from shortest to longest
    std::sort(processes.begin(),
              processes.end(),
              compare);

    // Step 2: Find the highest arrival time for the processes
    //         Set arrival time for all processes to highest arrival time plus one

    // Step 3:
    // For all processes

    for (auto item : processes)
    {
        // Without this, turnaround time calculations are incorrect
        // due to completion time being less than arrival time.
        if (current_time < item->get_arrival_time())
        {
            current_time = item->get_arrival_time();
        }

        //   Set the completion time for the process to previous completion_time plus burst time
        //   Set the turn around time for the process to completion time minus arrival time
        //   Calculate the wait time to completion minus burst time
        //   Set the wait time for the process
        //   Increment total wait time
        //   Increment total turnaround time

    }

    std::cout << "SJF Scheduling:" << std::endl;
    std::cout << "Process ID\tCompletion Time\tBurst Time\tArrival Time\tWaiting Time\tTurnaround Time" << std::endl;
    for (auto item : processes)
    {
        std::cout << "  " << *item << std::endl;
    }
    std::cout << "  Average waiting time (tics): " << total_waiting / processes.size() << std::endl;
    std::cout << "  Average turnaround time (tics): " << total_turnaround / processes.size() << std::endl << std::endl;
}
}