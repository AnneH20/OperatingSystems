#include <cse4733/power_calculator.hpp>

int main() {
    cse4733::PowerCalculator powerCalculator;
    powerCalculator.start();

    return 0;
}
